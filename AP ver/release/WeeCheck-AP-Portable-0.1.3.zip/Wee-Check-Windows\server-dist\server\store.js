import Database from 'better-sqlite3';
import argon2 from 'argon2';
import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { defaultRoster } from '../src/defaultRoster.js';
import { currentOpeningSlot, effectiveMode, normalizeOpening } from '../src/operation.js';
import { blindIndex, dataDir, decryptBytes, decryptText, encryptBytes, encryptText } from './security.js';
const dbPath = join(dataDir, 'wee-check.sqlite');
const backupDir = join(dataDir, 'backups');
const kstDay = (date = new Date()) => new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Seoul' }).format(date);
const tokenHash = (token) => createHash('sha256').update(token).digest('hex');
const addMinutes = (date, minutes) => new Date(date.getTime() + minutes * 60_000).toISOString();
export class CapacityError extends Error {
    details;
    code = 'CAPACITY_FULL';
    constructor(details) {
        super('현재 정원이 모두 찼습니다.');
        this.details = details;
    }
}
export class Store {
    db = new Database(dbPath);
    constructor() {
        this.db.pragma('journal_mode = WAL');
        this.db.pragma('foreign_keys = ON');
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS admins(id TEXT PRIMARY KEY, password_hash TEXT NOT NULL, password_changed INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS school_classes(id TEXT PRIMARY KEY, grade TEXT NOT NULL, class_name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, UNIQUE(grade,class_name));
      CREATE TABLE IF NOT EXISTS students(id TEXT PRIMARY KEY, grade TEXT NOT NULL, class_name TEXT NOT NULL, name_cipher TEXT NOT NULL, identity_hash TEXT UNIQUE NOT NULL, active INTEGER NOT NULL DEFAULT 1);
      CREATE TABLE IF NOT EXISTS attendance(id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES students(id), direction TEXT NOT NULL CHECK(direction IN ('in','out')), mood TEXT, occurred_at TEXT NOT NULL, day TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS attendance_day_idx ON attendance(day, occurred_at);
      CREATE TABLE IF NOT EXISTS counseling(id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES students(id), details_cipher TEXT NOT NULL, priority TEXT NOT NULL, completed_at TEXT, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS waitlist(id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES students(id), token_hash TEXT UNIQUE NOT NULL, mood TEXT, status TEXT NOT NULL, slot_key TEXT NOT NULL, max_play_minutes INTEGER NOT NULL, joined_at TEXT NOT NULL, reserved_at TEXT, expires_at TEXT, finished_at TEXT);
      CREATE INDEX IF NOT EXISTS waitlist_active_idx ON waitlist(status, joined_at);
      CREATE TABLE IF NOT EXISTS access_sessions(id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL, public_url TEXT, starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
      CREATE TABLE IF NOT EXISTS audit_logs(id TEXT PRIMARY KEY, action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT, occurred_at TEXT NOT NULL);
    `);
        this.ensureColumn('attendance', 'planned_end_at', 'TEXT');
        this.ensureColumn('attendance', 'max_play_minutes', 'INTEGER');
        this.ensureColumn('attendance', 'grade_snapshot', 'TEXT');
        this.ensureColumn('attendance', 'class_snapshot', 'TEXT');
        this.ensureColumn('counseling', 'grade_snapshot', 'TEXT');
        this.ensureColumn('counseling', 'class_snapshot', 'TEXT');
        this.db.exec(`
      UPDATE attendance SET grade_snapshot=(SELECT grade FROM students WHERE students.id=attendance.student_id) WHERE grade_snapshot IS NULL;
      UPDATE attendance SET class_snapshot=(SELECT class_name FROM students WHERE students.id=attendance.student_id) WHERE class_snapshot IS NULL;
      UPDATE counseling SET grade_snapshot=(SELECT grade FROM students WHERE students.id=counseling.student_id) WHERE grade_snapshot IS NULL;
      UPDATE counseling SET class_snapshot=(SELECT class_name FROM students WHERE students.id=counseling.student_id) WHERE class_snapshot IS NULL;
    `);
        const legacyEntries = this.db.prepare("SELECT id,occurred_at FROM attendance WHERE direction='in' AND planned_end_at IS NULL").all();
        const backfillEntry = this.db.prepare('UPDATE attendance SET planned_end_at=?,max_play_minutes=30 WHERE id=?');
        for (const entry of legacyEntries)
            backfillEntry.run(addMinutes(new Date(entry.occurred_at), 30), entry.id);
    }
    ensureColumn(table, column, definition) {
        const columns = this.db.prepare(`PRAGMA table_info(${table})`).all();
        if (!columns.some(item => item.name === column))
            this.db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    }
    async initialize() {
        if (!this.db.prepare('SELECT 1 FROM admins LIMIT 1').get())
            this.db.prepare('INSERT INTO admins VALUES(?,?,0)').run('admin', await argon2.hash('0000', { type: argon2.argon2id }));
        if (!this.getSetting('school'))
            this.setSetting('school', { schoolType: 'elementary', schoolName: '', academicYear: String(new Date().getFullYear()) });
        const operation = this.getSetting('operation') || { manualMode: 'open' };
        this.setSetting('operation', { ...operation, manualMode: operation.manualMode || 'open', opening: normalizeOpening(operation.opening) });
        if (!this.db.prepare('SELECT 1 FROM students LIMIT 1').get())
            this.replaceRoster(defaultRoster);
        this.syncClassesFromStudents();
    }
    getSetting(key) { const row = this.db.prepare('SELECT value FROM app_settings WHERE key=?').get(key); return row ? JSON.parse(row.value) : null; }
    setSetting(key, value) { this.db.prepare('INSERT INTO app_settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, JSON.stringify(value)); }
    audit(action, entityType, entityId) { this.db.prepare('INSERT INTO audit_logs VALUES(?,?,?,?,?)').run(randomUUID(), action, entityType, entityId || null, new Date().toISOString()); }
    async verifyPassword(password) { const row = this.db.prepare('SELECT password_hash FROM admins WHERE id=?').get('admin'); return argon2.verify(row.password_hash, password); }
    passwordChanged() { return Boolean(this.db.prepare('SELECT password_changed FROM admins WHERE id=?').get('admin').password_changed); }
    async changePassword(password) { this.db.prepare('UPDATE admins SET password_hash=?, password_changed=1 WHERE id=?').run(await argon2.hash(password, { type: argon2.argon2id }), 'admin'); this.audit('password_changed', 'admin', 'admin'); }
    operation() { const value = this.getSetting('operation') || {}; return { manualMode: (value.manualMode || 'open'), opening: normalizeOpening(value.opening) }; }
    saveOperation(input) { const opening = normalizeOpening(input?.opening); this.setSetting('operation', { manualMode: input?.manualMode || 'open', opening }); this.reconcileQueue(); this.audit('operation_saved', 'settings'); }
    currentRule(now = new Date()) {
        const operation = this.operation(), slotInfo = currentOpeningSlot(operation.opening, now), slotIndex = slotInfo ? operation.opening.week[slotInfo.day].indexOf(slotInfo.slot) : -1;
        return { open: effectiveMode(operation.manualMode, operation.opening, now) === 'open', enabled: operation.opening.capacity.enabled, limit: operation.opening.capacity.limit, grades: slotInfo?.slot.grades || [], maxPlayMinutes: slotInfo?.slot.maxPlayMinutes || operation.opening.capacity.manualMaxPlayMinutes, slotKey: slotInfo ? `${kstDay(now)}:${slotInfo.day}:${slotIndex}:${slotInfo.slot.start}-${slotInfo.slot.end}` : `manual:${kstDay(now)}`, slotEnd: slotInfo ? this.slotEndIso(now, slotInfo.slot.end) : null };
    }
    slotEndIso(now, end) { const [hour, minute] = end.split(':').map(Number), parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now), part = (type) => Number(parts.find(item => item.type === type)?.value); return new Date(Date.UTC(part('year'), part('month') - 1, part('day'), hour - 9, minute)).toISOString(); }
    syncClassesFromStudents() { const rows = this.db.prepare('SELECT DISTINCT grade,class_name FROM students WHERE active=1').all(), insert = this.db.prepare('INSERT INTO school_classes VALUES(?,?,?,1) ON CONFLICT(grade,class_name) DO UPDATE SET active=1'); for (const row of rows)
        insert.run(randomUUID(), row.grade, row.class_name); }
    replaceRoster(roster) {
        this.db.transaction(() => { this.db.prepare('UPDATE students SET active=0').run(); this.db.prepare('UPDATE school_classes SET active=0').run(); const find = this.db.prepare('SELECT id FROM students WHERE identity_hash=?'), insert = this.db.prepare('INSERT INTO students VALUES(?,?,?,?,?,1)'), activate = this.db.prepare('UPDATE students SET active=1,grade=?,class_name=?,name_cipher=? WHERE id=?'), upsertClass = this.db.prepare('INSERT INTO school_classes VALUES(?,?,?,1) ON CONFLICT(grade,class_name) DO UPDATE SET active=1'); for (const [grade, classes] of Object.entries(roster))
            for (const [className, names] of Object.entries(classes)) {
                upsertClass.run(randomUUID(), grade, className);
                for (const name of names) {
                    const hash = blindIndex(`${grade}\0${className}\0${name}`), row = find.get(hash);
                    if (row)
                        activate.run(grade, className, encryptText(name), row.id);
                    else
                        insert.run(randomUUID(), grade, className, encryptText(name), hash);
                }
            } this.audit('roster_replaced', 'students'); })();
    }
    roster() { const result = {}, classes = this.db.prepare('SELECT grade,class_name FROM school_classes WHERE active=1 ORDER BY grade,class_name').all(); for (const row of classes)
        (result[row.grade] ??= {})[row.class_name] = []; const rows = this.db.prepare('SELECT grade,class_name,name_cipher FROM students WHERE active=1 ORDER BY grade,class_name').all(); for (const row of rows)
        ((result[row.grade] ??= {})[row.class_name] ??= []).push(decryptText(row.name_cipher)); for (const classesByGrade of Object.values(result))
        for (const names of Object.values(classesByGrade))
            names.sort((a, b) => a.localeCompare(b, 'ko')); return result; }
    rosterDetails() { const classes = this.db.prepare('SELECT id,grade,class_name FROM school_classes WHERE active=1 ORDER BY grade,class_name').all(), students = this.db.prepare('SELECT id,grade,class_name,name_cipher FROM students WHERE active=1 ORDER BY grade,class_name').all(); return classes.map(item => ({ id: item.id, grade: item.grade, name: item.class_name, students: students.filter(student => student.grade === item.grade && student.class_name === item.class_name).map(student => ({ id: student.id, name: decryptText(student.name_cipher) })).sort((a, b) => a.name.localeCompare(b.name, 'ko')) })); }
    createClass(grade, name) { grade = grade.trim(); name = name.trim(); if (!grade || !name)
        throw new Error('학년과 학급 이름을 입력해 주세요.'); const existing = this.db.prepare('SELECT id,active FROM school_classes WHERE grade=? AND class_name=?').get(grade, name); if (existing?.active)
        throw new Error('이미 등록된 학급입니다.'); const id = existing?.id || randomUUID(); if (existing)
        this.db.prepare('UPDATE school_classes SET active=1 WHERE id=?').run(id);
    else
        this.db.prepare('INSERT INTO school_classes VALUES(?,?,?,1)').run(id, grade, name); this.audit('class_created', 'school_class', id); return id; }
    renameClass(id, name) { name = name.trim(); if (!name)
        throw new Error('학급 이름을 입력해 주세요.'); this.db.transaction(() => { const row = this.db.prepare('SELECT grade,class_name FROM school_classes WHERE id=? AND active=1').get(id); if (!row)
        throw new Error('학급을 찾을 수 없습니다.'); if (this.db.prepare('SELECT 1 FROM school_classes WHERE grade=? AND class_name=? AND active=1 AND id<>?').get(row.grade, name, id))
        throw new Error('같은 학년에 이미 같은 이름의 학급이 있습니다.'); const students = this.db.prepare('SELECT id,name_cipher FROM students WHERE grade=? AND class_name=? AND active=1').all(row.grade, row.class_name); for (const student of students) {
        const studentName = decryptText(student.name_cipher), hash = blindIndex(`${row.grade}\0${name}\0${studentName}`);
        if (this.db.prepare('SELECT 1 FROM students WHERE identity_hash=? AND id<>?').get(hash, student.id))
            throw new Error(`${studentName} 학생과 동일한 정보가 이미 있습니다.`);
        this.db.prepare('UPDATE students SET class_name=?,identity_hash=? WHERE id=?').run(name, hash, student.id);
    } this.db.prepare('UPDATE school_classes SET class_name=? WHERE id=?').run(name, id); this.audit('class_renamed', 'school_class', id); })(); }
    deleteClass(id) { const row = this.db.prepare('SELECT grade,class_name FROM school_classes WHERE id=? AND active=1').get(id); if (!row)
        throw new Error('학급을 찾을 수 없습니다.'); if (this.db.prepare('SELECT 1 FROM students WHERE grade=? AND class_name=? AND active=1').get(row.grade, row.class_name))
        throw new Error('학생이 남아 있는 학급은 삭제할 수 없습니다.'); this.db.prepare('UPDATE school_classes SET active=0 WHERE id=?').run(id); this.audit('class_removed', 'school_class', id); }
    studentId(grade, className, name) { return this.db.prepare('SELECT id FROM students WHERE identity_hash=? AND active=1').get(blindIndex(`${grade}\0${className}\0${name}`))?.id; }
    addStudent(grade, className, name) { name = name.trim(); if (!name)
        throw new Error('학생 이름을 입력해 주세요.'); if (!this.db.prepare('SELECT 1 FROM school_classes WHERE grade=? AND class_name=? AND active=1').get(grade, className))
        throw new Error('학급을 찾을 수 없습니다.'); const hash = blindIndex(`${grade}\0${className}\0${name}`), old = this.db.prepare('SELECT id,active FROM students WHERE identity_hash=?').get(hash); if (old?.active)
        throw new Error('같은 학급에 동일한 이름의 학생이 있습니다.'); const id = old?.id || randomUUID(); if (old)
        this.db.prepare('UPDATE students SET active=1,name_cipher=?,grade=?,class_name=? WHERE id=?').run(encryptText(name), grade, className, id);
    else
        this.db.prepare('INSERT INTO students VALUES(?,?,?,?,?,1)').run(id, grade, className, encryptText(name), hash); this.audit('student_created', 'student', id); return id; }
    updateStudent(id, grade, className, name) { name = name.trim(); if (!name)
        throw new Error('학생 이름을 입력해 주세요.'); if (!this.db.prepare('SELECT 1 FROM school_classes WHERE grade=? AND class_name=? AND active=1').get(grade, className))
        throw new Error('이동할 학급을 찾을 수 없습니다.'); const hash = blindIndex(`${grade}\0${className}\0${name}`); if (this.db.prepare('SELECT 1 FROM students WHERE identity_hash=? AND id<>?').get(hash, id))
        throw new Error('수정할 정보와 동일한 학생이 이미 있습니다.'); const result = this.db.prepare('UPDATE students SET grade=?,class_name=?,name_cipher=?,identity_hash=? WHERE id=? AND active=1').run(grade, className, encryptText(name), hash, id); if (!result.changes)
        throw new Error('학생을 찾을 수 없습니다.'); this.audit('student_updated', 'student', id); }
    removeStudents(ids) { const update = this.db.prepare('UPDATE students SET active=0 WHERE id=?'); this.db.transaction(() => { for (const id of ids)
        update.run(id); this.audit('students_removed', 'student'); })(); }
    moveStudents(ids, grade, className) { this.db.transaction(() => { if (!this.db.prepare('SELECT 1 FROM school_classes WHERE grade=? AND class_name=? AND active=1').get(grade, className))
        throw new Error('이동할 학급을 찾을 수 없습니다.'); for (const id of ids) {
        const row = this.db.prepare('SELECT name_cipher FROM students WHERE id=? AND active=1').get(id);
        if (!row)
            throw new Error('이동할 학생을 찾을 수 없습니다.');
        const name = decryptText(row.name_cipher), hash = blindIndex(`${grade}\0${className}\0${name}`);
        if (this.db.prepare('SELECT 1 FROM students WHERE identity_hash=? AND id<>?').get(hash, id))
            throw new Error(`${name} 학생과 동일한 정보가 이동할 학급에 있습니다.`);
        this.db.prepare('UPDATE students SET grade=?,class_name=?,identity_hash=? WHERE id=?').run(grade, className, hash, id);
    } this.audit('students_moved', 'student'); })(); }
    replaceClass(grade, className, names, mode) { this.db.transaction(() => { if (mode === 'replace')
        this.db.prepare('UPDATE students SET active=0 WHERE grade=? AND class_name=?').run(grade, className); for (const name of names) {
        const existing = this.studentId(grade, className, name);
        if (!existing)
            this.addStudent(grade, className, name);
    } })(); }
    rosterPreview(next) { const flatten = (roster) => new Set(Object.entries(roster).flatMap(([grade, classes]) => Object.entries(classes).flatMap(([schoolClass, names]) => names.map(name => JSON.stringify([grade, schoolClass, name]))))), current = flatten(this.roster()), future = flatten(next); return { added: [...future].filter(x => !current.has(x)).length, removed: [...current].filter(x => !future.has(x)).length, kept: [...future].filter(x => current.has(x)).length, total: future.size }; }
    settings() { return { ...(this.getSetting('school') || {}), roster: this.roster(), rosterDetails: this.rosterDetails(), ...this.operation() }; }
    saveSchool(input) { this.setSetting('school', { schoolType: input.schoolType, schoolName: input.schoolName, academicYear: input.academicYear || String(new Date().getFullYear()) }); if (input.roster)
        this.replaceRoster(input.roster); this.audit('school_saved', 'settings'); }
    records(day) { const rows = this.db.prepare(`SELECT a.*,s.name_cipher,s.grade current_grade,s.class_name current_class FROM attendance a JOIN students s ON s.id=a.student_id ${day ? 'WHERE a.day=?' : ''} ORDER BY a.occurred_at`).all(...(day ? [day] : [])); return rows.map(r => ({ id: r.id, studentId: r.student_id, grade: r.grade_snapshot || r.current_grade, schoolClass: r.class_snapshot || r.current_class, name: decryptText(r.name_cipher), direction: r.direction, mood: r.mood, timestamp: r.occurred_at, plannedEndAt: r.planned_end_at, maxPlayMinutes: r.max_play_minutes })); }
    presentRows(day = kstDay()) { return this.db.prepare(`SELECT a.*,s.name_cipher,s.grade,s.class_name FROM attendance a JOIN students s ON s.id=a.student_id JOIN (SELECT student_id,MAX(occurred_at) occurred_at FROM attendance WHERE day=? GROUP BY student_id) latest ON latest.student_id=a.student_id AND latest.occurred_at=a.occurred_at WHERE a.direction='in'`).all(day); }
    queueSnapshot(proposedDuration) { this.reconcileQueue(); const rule = this.currentRule(), present = this.presentRows(), reserved = this.db.prepare("SELECT * FROM waitlist WHERE status='reserved' ORDER BY reserved_at").all(), waiting = this.db.prepare("SELECT * FROM waitlist WHERE status='waiting' ORDER BY joined_at").all(), now = Date.now(), overdue = present.some(row => row.planned_end_at && Date.parse(row.planned_end_at) <= now); let estimatedAt = null; if (!overdue) {
        const lanes = [...present.map(row => row.planned_end_at ? Date.parse(row.planned_end_at) : now + rule.maxPlayMinutes * 60000), ...reserved.map(row => Date.parse(row.expires_at) + row.max_play_minutes * 60000)];
        while (lanes.length < rule.limit)
            lanes.push(now);
        lanes.sort((a, b) => a - b);
        for (const item of waiting) {
            const next = lanes.shift() || now;
            lanes.push(next + item.max_play_minutes * 60000);
            lanes.sort((a, b) => a - b);
        }
        estimatedAt = new Date(lanes[0] || now).toISOString();
        if (rule.slotEnd && Date.parse(estimatedAt) >= Date.parse(rule.slotEnd))
            estimatedAt = null;
    } return { enabled: rule.enabled, limit: rule.limit, present: present.length, reserved: reserved.length, waiting: waiting.length, available: Math.max(0, rule.limit - present.length - reserved.length), maxPlayMinutes: proposedDuration || rule.maxPlayMinutes, grades: rule.grades, slotEnd: rule.slotEnd, delayed: overdue, proposedPosition: waiting.length + 1, estimatedAt }; }
    addAttendance(studentId, direction, mood, ticket) { return this.db.transaction(() => { this.reconcileQueue(false); const student = this.db.prepare('SELECT id,grade,class_name FROM students WHERE id=? AND active=1').get(studentId); if (!student)
        throw new Error('학생을 찾을 수 없습니다.'); const day = kstDay(), latest = this.db.prepare('SELECT direction FROM attendance WHERE student_id=? AND day=? ORDER BY occurred_at DESC LIMIT 1').get(studentId, day); if (direction === 'in' && latest?.direction === 'in')
        throw new Error('이미 들어온 상태입니다.'); if (direction === 'out' && latest?.direction !== 'in')
        throw new Error('오늘 들어오기 기록이 없습니다.'); const rule = this.currentRule(); let wait = null; if (direction === 'in' && rule.enabled) {
        if (!rule.open)
            throw new Error('현재는 개방 시간이 아닙니다.');
        if (ticket) {
            wait = this.db.prepare("SELECT * FROM waitlist WHERE token_hash=? AND student_id=? AND status='reserved'").get(tokenHash(ticket), studentId);
            if (!wait || !wait.expires_at || Date.parse(wait.expires_at) <= Date.now())
                throw new Error('입실 예약 시간이 지났습니다. 다시 대기를 확인해 주세요.');
        }
        else {
            const snapshot = this.queueSnapshot(rule.maxPlayMinutes);
            if (snapshot.available <= 0 || snapshot.waiting > 0)
                throw new CapacityError(snapshot);
        }
    } const id = randomUUID(), timestamp = new Date().toISOString(), duration = wait?.max_play_minutes || rule.maxPlayMinutes, planned = direction === 'in' ? addMinutes(new Date(timestamp), duration) : null; this.db.prepare('INSERT INTO attendance(id,student_id,direction,mood,occurred_at,day,planned_end_at,max_play_minutes,grade_snapshot,class_snapshot) VALUES(?,?,?,?,?,?,?,?,?,?)').run(id, studentId, direction, direction === 'in' ? mood ?? wait?.mood ?? null : null, timestamp, day, planned, direction === 'in' ? duration : null, student.grade, student.class_name); if (wait)
        this.db.prepare("UPDATE waitlist SET status='admitted',finished_at=? WHERE id=?").run(timestamp, wait.id); this.audit(`attendance_${direction}`, 'attendance', id); if (direction === 'out')
        this.reconcileQueue(false); return { id, timestamp, plannedEndAt: planned, maxPlayMinutes: direction === 'in' ? duration : null }; })(); }
    joinWaitlist(studentId, mood) { return this.db.transaction(() => { this.reconcileQueue(false); const student = this.db.prepare('SELECT id,grade FROM students WHERE id=? AND active=1').get(studentId); if (!student)
        throw new Error('학생을 찾을 수 없습니다.'); const rule = this.currentRule(), snapshot = this.queueSnapshot(rule.maxPlayMinutes); if (!rule.open || !rule.enabled)
        throw new Error('현재 대기를 신청할 수 없습니다.'); if (snapshot.available > 0 && snapshot.waiting === 0)
        throw new Error('지금은 바로 입실할 수 있습니다.'); if (rule.grades.length && !rule.grades.includes(student.grade))
        throw new Error('현재 대기 신청 대상 학년이 아닙니다.'); if (this.db.prepare("SELECT 1 FROM waitlist WHERE student_id=? AND status IN ('waiting','reserved')").get(studentId))
        throw new Error('이미 대기 중입니다.'); const raw = randomBytes(24).toString('base64url'), id = randomUUID(), joined = new Date().toISOString(); this.db.prepare("INSERT INTO waitlist(id,student_id,token_hash,mood,status,slot_key,max_play_minutes,joined_at) VALUES(?,?,?,?, 'waiting',?,?,?)").run(id, studentId, tokenHash(raw), mood ?? null, rule.slotKey, rule.maxPlayMinutes, joined); this.audit('waitlist_joined', 'waitlist', id); this.reconcileQueue(false); return { ticket: raw, ...this.waitStatus(raw) }; })(); }
    waitStatus(ticket) { this.reconcileQueue(); const row = this.db.prepare('SELECT * FROM waitlist WHERE token_hash=?').get(tokenHash(ticket)); if (!row)
        throw new Error('대기표를 찾을 수 없습니다.'); const ahead = row.status === 'waiting' ? Number(this.db.prepare("SELECT COUNT(*) count FROM waitlist WHERE status='waiting' AND joined_at<?").get(row.joined_at).count) : 0, snapshot = this.queueSnapshot(row.max_play_minutes); return { id: row.id, status: row.status, position: row.status === 'waiting' ? ahead + 1 : 0, reservedAt: row.reserved_at, expiresAt: row.expires_at, estimatedAt: snapshot.estimatedAt, delayed: snapshot.delayed, slotEnd: snapshot.slotEnd }; }
    cancelWait(ticket) { const result = this.db.prepare("UPDATE waitlist SET status='cancelled',finished_at=? WHERE token_hash=? AND status IN ('waiting','reserved')").run(new Date().toISOString(), tokenHash(ticket)); if (!result.changes)
        throw new Error('취소할 대기 신청이 없습니다.'); this.reconcileQueue(); }
    reconcileQueue(promote = true) { const now = new Date(), nowIso = now.toISOString(), rule = this.currentRule(now); this.db.prepare("UPDATE waitlist SET status='expired',finished_at=? WHERE status='reserved' AND expires_at<=?").run(nowIso, nowIso); if (!rule.open || !rule.enabled) {
        this.db.prepare("UPDATE waitlist SET status='cancelled',finished_at=? WHERE status IN ('waiting','reserved')").run(nowIso);
        return;
    } this.db.prepare("UPDATE waitlist SET status='cancelled',finished_at=? WHERE status IN ('waiting','reserved') AND slot_key<>?").run(nowIso, rule.slotKey); if (!promote)
        return; let available = rule.limit - this.presentRows().length - Number(this.db.prepare("SELECT COUNT(*) count FROM waitlist WHERE status='reserved'").get().count); while (available > 0) {
        const next = this.db.prepare("SELECT id FROM waitlist WHERE status='waiting' ORDER BY joined_at LIMIT 1").get();
        if (!next)
            break;
        this.db.prepare("UPDATE waitlist SET status='reserved',reserved_at=?,expires_at=? WHERE id=?").run(nowIso, addMinutes(now, 5), next.id);
        available--;
    } }
    adminWaitlist() { this.reconcileQueue(); const rows = this.db.prepare("SELECT w.*,s.name_cipher,s.grade,s.class_name FROM waitlist w JOIN students s ON s.id=w.student_id WHERE w.status IN ('waiting','reserved') ORDER BY CASE w.status WHEN 'reserved' THEN 0 ELSE 1 END,w.joined_at").all(); let position = 0; return rows.map(row => ({ id: row.id, studentId: row.student_id, name: decryptText(row.name_cipher), grade: row.grade, schoolClass: row.class_name, status: row.status, position: row.status === 'waiting' ? ++position : 0, joinedAt: row.joined_at, reservedAt: row.reserved_at, expiresAt: row.expires_at })); }
    adminCancelWait(id) { const result = this.db.prepare("UPDATE waitlist SET status='cancelled',finished_at=? WHERE id=? AND status IN ('waiting','reserved')").run(new Date().toISOString(), id); if (!result.changes)
        throw new Error('대기 항목을 찾을 수 없습니다.'); this.reconcileQueue(); }
    adminAdvanceWait(id) { const row = this.db.prepare("SELECT status FROM waitlist WHERE id=? AND status='reserved'").get(id); if (!row)
        throw new Error('넘길 예약을 찾을 수 없습니다.'); this.db.prepare("UPDATE waitlist SET status='expired',finished_at=? WHERE id=?").run(new Date().toISOString(), id); this.reconcileQueue(); }
    requests() { const rows = this.db.prepare('SELECT c.*,s.name_cipher,s.grade current_grade,s.class_name current_class FROM counseling c JOIN students s ON s.id=c.student_id ORDER BY c.created_at DESC').all(); return rows.map(r => ({ id: r.id, studentId: r.student_id, grade: r.grade_snapshot || r.current_grade, schoolClass: r.class_snapshot || r.current_class, name: decryptText(r.name_cipher), timestamp: r.created_at, completed: Boolean(r.completed_at), details: JSON.parse(decryptText(r.details_cipher)), priority: r.priority })); }
    addRequest(studentId, details, priority) { const student = this.db.prepare('SELECT grade,class_name FROM students WHERE id=?').get(studentId); if (!student)
        throw new Error('학생을 찾을 수 없습니다.'); const id = randomUUID(); this.db.prepare('INSERT INTO counseling(id,student_id,details_cipher,priority,completed_at,created_at,grade_snapshot,class_snapshot) VALUES(?,?,?,?,NULL,?,?,?)').run(id, studentId, encryptText(JSON.stringify(details)), priority, new Date().toISOString(), student.grade, student.class_name); this.audit('counseling_created', 'counseling', id); return id; }
    completeRequest(id) { this.db.prepare('UPDATE counseling SET completed_at=? WHERE id=?').run(new Date().toISOString(), id); this.audit('counseling_completed', 'counseling', id); }
    createAccessSession(token, publicUrl) { this.db.prepare('UPDATE access_sessions SET active=0').run(); const proposedId = randomUUID(), hash = tokenHash(token), starts = new Date(), ends = new Date(starts); ends.setHours(24, 0, 0, 0); this.db.prepare('INSERT INTO access_sessions VALUES(?,?,?,?,?,1) ON CONFLICT(token_hash) DO UPDATE SET public_url=excluded.public_url,starts_at=excluded.starts_at,ends_at=excluded.ends_at,active=1').run(proposedId, hash, publicUrl || null, starts.toISOString(), ends.toISOString()); const row = this.db.prepare('SELECT id FROM access_sessions WHERE token_hash=?').get(hash); return { id: row.id, startsAt: starts.toISOString(), endsAt: ends.toISOString() }; }
    validateToken(token) { return Boolean(this.db.prepare('SELECT 1 FROM access_sessions WHERE token_hash=? AND active=1 AND ends_at>?').get(tokenHash(token), new Date().toISOString())); }
    activeSession() { return this.db.prepare('SELECT id,public_url publicUrl,starts_at startsAt,ends_at endsAt FROM access_sessions WHERE active=1 AND ends_at>? ORDER BY starts_at DESC LIMIT 1').get(new Date().toISOString()) || null; }
    stopSessions() { this.db.prepare('UPDATE access_sessions SET active=0').run(); this.audit('access_stopped', 'access_session'); }
    backup() { this.db.pragma('wal_checkpoint(TRUNCATE)'); const stamp = new Date().toISOString().replace(/[:.]/g, '-'), path = join(backupDir, `wee-check-${stamp}.wcbak`); if (!existsSync(backupDir))
        mkdirSync(backupDir, { recursive: true }); writeFileSync(path, encryptBytes(readFileSync(dbPath))); const files = readdirSync(backupDir).filter(x => x.endsWith('.wcbak')).sort().reverse(); for (const old of files.slice(30))
        unlinkSync(join(backupDir, old)); return path; }
    backups() { if (!existsSync(backupDir))
        return []; return readdirSync(backupDir).filter(name => name.endsWith('.wcbak')).sort().reverse(); }
    restoreNamed(name) { if (!/^[a-zA-Z0-9._-]+\.wcbak$/.test(name))
        throw new Error('올바르지 않은 백업 이름입니다.'); this.restore(join(backupDir, name)); }
    restore(path) { const temp = `${dbPath}.restore`; writeFileSync(temp, decryptBytes(readFileSync(path))); const check = new Database(temp, { readonly: true }); check.prepare('PRAGMA integrity_check').get(); check.close(); this.db.close(); copyFileSync(dbPath, `${dbPath}.before-restore`); renameSync(temp, dbPath); }
    closeAcademicYear() { const backup = this.backup(); this.db.transaction(() => { this.stopSessions(); this.db.prepare('DELETE FROM waitlist').run(); this.db.prepare('DELETE FROM attendance').run(); this.db.prepare('DELETE FROM counseling').run(); this.db.prepare('UPDATE students SET active=0').run(); this.db.prepare('UPDATE school_classes SET active=0').run(); this.audit('academic_year_closed', 'system'); })(); return backup; }
}
