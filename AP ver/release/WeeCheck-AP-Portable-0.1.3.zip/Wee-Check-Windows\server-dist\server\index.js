import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import staticPlugin from '@fastify/static';
import QRCode from 'qrcode';
import { randomBytes, randomUUID } from 'node:crypto';
import { existsSync } from 'node:fs';
import { networkInterfaces } from 'node:os';
import { resolve } from 'node:path';
import { CapacityError, Store } from './store.js';
import { requestPriority, validDetails } from '../src/counseling.js';
const store = new Store();
await store.initialize();
store.stopSessions();
const dist = resolve(process.cwd(), 'dist');
const adminSessions = new Map();
const loginAttempts = new Map();
const listeners = new Set();
let accessStatus = { state: 'stopped' };
let currentStudentToken = '';
let accessGeneration = 0;
const adminPort = Number(process.env.WEE_CHECK_ADMIN_PORT || 4173);
const studentPort = Number(process.env.WEE_CHECK_STUDENT_PORT || 4174);
const studentHost = process.env.WEE_CHECK_STUDENT_BIND || '0.0.0.0';
function isPrivateIpv4(address) {
    const parts = address.split('.').map(Number);
    return parts.length === 4 && (parts[0] === 10 || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) || (parts[0] === 192 && parts[1] === 168));
}
function lanAddress() {
    const configured = process.env.WEE_CHECK_LAN_ADDRESS?.trim();
    if (configured)
        return isPrivateIpv4(configured) ? configured : '';
    const candidates = Object.entries(networkInterfaces()).flatMap(([name, addresses]) => (addresses || [])
        .filter(item => item.family === 'IPv4' && !item.internal && isPrivateIpv4(item.address))
        .map(item => ({ name, address: item.address, score: (/wi-?fi|wlan|wireless|무선/i.test(name) ? 100 : 0) - (/virtual|vmware|hyper-v|vethernet|docker|wsl|vpn|tailscale/i.test(name) ? 100 : 0) })))
        .sort((a, b) => b.score - a.score);
    return candidates[0]?.address || '';
}
function emit(type = 'update') { for (const reply of listeners)
    reply.write(`event: ${type}\ndata: ${JSON.stringify({ at: Date.now() })}\n\n`); }
function openEventStream(request, reply) { reply.hijack(); reply.raw.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' }); listeners.add(reply.raw); reply.raw.write('retry: 2000\nevent: ready\ndata: {}\n\n'); const heartbeat = setInterval(() => reply.raw.write(': keepalive\n\n'), 25_000); request.raw.on('close', () => { clearInterval(heartbeat); listeners.delete(reply.raw); }); }
function bearer(header) { return header?.startsWith('Bearer ') ? header.slice(7) : ''; }
function requireAdmin(request, reply, done) { const sid = request.cookies?.wee_admin; const expiry = sid && adminSessions.get(sid); if (!expiry || expiry < Date.now())
    return reply.code(401).send({ error: '로그인이 필요합니다.' }); done(); }
function publicMode() { return store.operation(); }
function rosterResponse() { const settings = store.settings(); return { roster: settings.roster, rosterDetails: settings.rosterDetails }; }
const admin = Fastify({ logger: { level: 'warn', redact: ['req.headers.authorization', 'req.headers.cookie', 'body'] }, bodyLimit: 1024 * 1024 });
await admin.register(cookie);
admin.addHook('onSend', async (_req, reply, payload) => { reply.header('Cache-Control', 'no-store'); reply.header('X-Content-Type-Options', 'nosniff'); reply.header('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'"); return payload; });
admin.get('/healthz', async () => ({
    ok: true,
    service: 'wee-check-ap',
    pid: process.pid,
    adminPort,
    studentPort,
    access: { state: accessStatus.state, publicUrl: accessStatus.publicUrl, studentUrl: accessStatus.studentUrl, message: accessStatus.message },
}));
admin.post('/api/admin/login', async (request, reply) => {
    const ip = request.ip, state = loginAttempts.get(ip);
    if (state && state.until > Date.now())
        return reply.code(429).send({ error: '로그인 시도가 잠시 제한되었습니다.' });
    if (!await store.verifyPassword(String(request.body?.password || ''))) {
        const count = (state?.count || 0) + 1;
        loginAttempts.set(ip, { count, until: count >= 5 ? Date.now() + 60_000 : 0 });
        await new Promise(r => setTimeout(r, Math.min(1500, count * 250)));
        return reply.code(401).send({ error: '비밀번호가 올바르지 않습니다.' });
    }
    loginAttempts.delete(ip);
    const sid = randomUUID();
    adminSessions.set(sid, Date.now() + 8 * 60 * 60 * 1000);
    reply.setCookie('wee_admin', sid, { httpOnly: true, sameSite: 'strict', path: '/', maxAge: 8 * 60 * 60 });
    return { ok: true };
});
admin.post('/api/admin/logout', { preHandler: requireAdmin }, async (request, reply) => { if (request.cookies.wee_admin)
    adminSessions.delete(request.cookies.wee_admin); reply.clearCookie('wee_admin', { path: '/' }); return { ok: true }; });
admin.get('/api/admin/bootstrap', { preHandler: requireAdmin }, async () => ({ settings: store.settings(), records: store.records(), requests: store.requests(), capacity: store.queueSnapshot(), waitlist: store.adminWaitlist(), passwordChanged: store.passwordChanged(), access: accessStatus.state === 'online' ? { ...store.activeSession(), ...accessStatus } : accessStatus }));
admin.put('/api/admin/password', { preHandler: requireAdmin }, async (request, reply) => { const password = String(request.body?.password || ''); if (password.length < 8)
    return reply.code(400).send({ error: '비밀번호는 8자 이상이어야 합니다.' }); await store.changePassword(password); return { ok: true }; });
admin.put('/api/admin/school', { preHandler: requireAdmin }, async (request) => { store.saveSchool(request.body); emit(); return { ok: true, settings: store.settings() }; });
admin.put('/api/admin/operation', { preHandler: requireAdmin }, async (request) => { store.saveOperation(request.body); emit(); return { ok: true }; });
admin.post('/api/admin/roster/classes', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.createClass(String(request.body?.grade || ''), String(request.body?.name || ''));
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(400).send({ error: e instanceof Error ? e.message : '학급을 추가하지 못했습니다.' });
} });
admin.patch('/api/admin/roster/classes/:id', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.renameClass(String(request.params.id), String(request.body?.name || ''));
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(400).send({ error: e instanceof Error ? e.message : '학급을 수정하지 못했습니다.' });
} });
admin.delete('/api/admin/roster/classes/:id', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.deleteClass(String(request.params.id));
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(409).send({ error: e instanceof Error ? e.message : '학급을 삭제하지 못했습니다.' });
} });
admin.post('/api/admin/roster/students', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.addStudent(String(request.body?.grade || ''), String(request.body?.schoolClass || ''), String(request.body?.name || ''));
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(400).send({ error: e instanceof Error ? e.message : '학생을 추가하지 못했습니다.' });
} });
admin.patch('/api/admin/roster/students/:id', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.updateStudent(String(request.params.id), String(request.body?.grade || ''), String(request.body?.schoolClass || ''), String(request.body?.name || ''));
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(409).send({ error: e instanceof Error ? e.message : '학생을 수정하지 못했습니다.' });
} });
admin.post('/api/admin/roster/students/remove', { preHandler: requireAdmin }, async (request, reply) => { try {
    const ids = Array.isArray(request.body?.ids) ? request.body.ids.map(String) : [];
    if (!ids.length)
        throw new Error('제외할 학생을 선택해 주세요.');
    store.removeStudents(ids);
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(400).send({ error: e instanceof Error ? e.message : '학생을 제외하지 못했습니다.' });
} });
admin.post('/api/admin/roster/students/move', { preHandler: requireAdmin }, async (request, reply) => { try {
    const ids = Array.isArray(request.body?.ids) ? request.body.ids.map(String) : [];
    if (!ids.length)
        throw new Error('이동할 학생을 선택해 주세요.');
    store.moveStudents(ids, String(request.body?.grade || ''), String(request.body?.schoolClass || ''));
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(409).send({ error: e instanceof Error ? e.message : '학생을 이동하지 못했습니다.' });
} });
admin.post('/api/admin/roster/bulk/preview', { preHandler: requireAdmin }, async (request, reply) => { try {
    if (request.body?.scope === 'class') {
        const names = [...new Set((Array.isArray(request.body?.names) ? request.body.names : []).map((name) => String(name).trim()).filter(Boolean))];
        const current = store.roster()[String(request.body.grade)]?.[String(request.body.schoolClass)] || [], next = request.body?.mode === 'append' ? [...new Set([...current, ...names])] : names;
        return { added: next.filter(name => !current.includes(name)).length, removed: current.filter(name => !next.includes(name)).length, kept: next.filter(name => current.includes(name)).length, total: next.length, names: next };
    }
    const roster = request.body?.roster;
    if (!roster || typeof roster !== 'object')
        throw new Error('명렬표 데이터를 확인해 주세요.');
    return store.rosterPreview(roster);
}
catch (e) {
    return reply.code(400).send({ error: e instanceof Error ? e.message : '미리보기를 만들지 못했습니다.' });
} });
admin.post('/api/admin/roster/bulk/commit', { preHandler: requireAdmin }, async (request, reply) => { try {
    if (request.body?.scope === 'class')
        store.replaceClass(String(request.body.grade), String(request.body.schoolClass), (Array.isArray(request.body.names) ? request.body.names : []).map((name) => String(name).trim()).filter(Boolean), request.body?.mode === 'append' ? 'append' : 'replace');
    else
        store.replaceRoster(request.body?.roster || {});
    emit();
    return { ok: true, ...rosterResponse() };
}
catch (e) {
    return reply.code(409).send({ error: e instanceof Error ? e.message : '명렬표를 반영하지 못했습니다.' });
} });
admin.get('/api/admin/waitlist', { preHandler: requireAdmin }, async () => ({ capacity: store.queueSnapshot(), items: store.adminWaitlist() }));
admin.post('/api/admin/waitlist/:id/cancel', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.adminCancelWait(String(request.params.id));
    emit('capacity');
    return { ok: true };
}
catch (e) {
    return reply.code(404).send({ error: e instanceof Error ? e.message : '대기를 취소하지 못했습니다.' });
} });
admin.post('/api/admin/waitlist/:id/advance', { preHandler: requireAdmin }, async (request, reply) => { try {
    store.adminAdvanceWait(String(request.params.id));
    emit('capacity');
    return { ok: true };
}
catch (e) {
    return reply.code(404).send({ error: e instanceof Error ? e.message : '다음 학생을 호출하지 못했습니다.' });
} });
admin.post('/api/admin/counseling/:id/complete', { preHandler: requireAdmin }, async (request) => { store.completeRequest(request.params.id); emit(); return { ok: true }; });
admin.get('/api/admin/events', { preHandler: requireAdmin }, openEventStream);
async function startAccess() {
    const generation = ++accessGeneration;
    store.stopSessions();
    currentStudentToken = randomBytes(32).toString('base64url');
    accessStatus = { state: 'starting' };
    const address = lanAddress();
    if (!address) {
        accessStatus = { state: 'error', message: '사용 가능한 사설 IPv4 주소를 찾지 못했습니다. Wi-Fi 연결과 WEE_CHECK_LAN_ADDRESS 값을 확인해 주세요.' };
        emit();
        return accessStatus;
    }
    const publicUrl = `http://${address}:${studentPort}`;
    const studentUrl = `${publicUrl}/#/s/${currentStudentToken}`;
    store.createAccessSession(currentStudentToken, publicUrl);
    const qr = await QRCode.toDataURL(studentUrl);
    if (generation !== accessGeneration)
        return accessStatus;
    accessStatus = { state: 'online', publicUrl, studentUrl, qr, message: '같은 보안 Wi-Fi에 연결된 기기에서만 접속할 수 있습니다.' };
    emit();
    return accessStatus;
}
admin.post('/api/admin/access/start', { preHandler: requireAdmin }, async () => startAccess());
admin.post('/api/admin/access/stop', { preHandler: requireAdmin }, async () => { accessGeneration++; accessStatus = { state: 'stopped' }; currentStudentToken = ''; store.stopSessions(); emit(); return { ok: true }; });
admin.post('/api/admin/backup', { preHandler: requireAdmin }, async () => ({ path: store.backup() }));
admin.get('/api/admin/backups', { preHandler: requireAdmin }, async () => ({ files: store.backups() }));
admin.post('/api/admin/backups/:name/restore', { preHandler: requireAdmin }, async (request) => { store.restoreNamed(request.params.name); setTimeout(() => process.exit(0), 250); return { ok: true, restarting: true }; });
admin.post('/api/admin/academic-year/close', { preHandler: requireAdmin }, async () => ({ backup: store.closeAcademicYear() }));
if (existsSync(dist))
    await admin.register(staticPlugin, { root: dist, wildcard: false });
admin.setNotFoundHandler((request, reply) => { if (existsSync(resolve(dist, 'index.html')))
    return reply.sendFile('index.html'); reply.code(404).send({ error: '관리자 화면을 먼저 빌드해야 합니다.' }); });
const student = Fastify({ logger: { level: 'warn', redact: ['req.headers.authorization', 'body'] }, bodyLimit: 64 * 1024 });
await student.register(rateLimit, { max: 120, timeWindow: '1 minute' });
student.get('/healthz', async () => ({ ok: true, access: accessStatus.state }));
student.addHook('onSend', async (_req, reply, payload) => { reply.header('Cache-Control', 'no-store'); reply.header('X-Robots-Tag', 'noindex, nofollow, noarchive'); reply.header('X-Content-Type-Options', 'nosniff'); return payload; });
student.addHook('preHandler', async (request, reply) => { const streamToken = request.url.startsWith('/api/student/events?') ? String(request.query?.token || '') : ''; if (request.url.startsWith('/api/student') && !store.validateToken(bearer(request.headers.authorization) || streamToken))
    return reply.code(401).send({ error: '학생 접속 시간이 끝났거나 QR이 올바르지 않습니다.' }); });
student.get('/api/student/events', openEventStream);
student.get('/api/student/operation', async () => publicMode());
student.get('/api/student/bootstrap', async () => { const settings = store.settings(); return { settings: { schoolName: settings.schoolName, schoolType: settings.schoolType, roster: settings.roster }, operation: publicMode(), capacity: store.queueSnapshot(), records: store.records(new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Seoul' }).format(new Date())) }; });
student.get('/api/student/capacity', async () => store.queueSnapshot());
student.get('/api/student/waitlist/:ticket', async (request, reply) => { try {
    return store.waitStatus(String(request.params.ticket));
}
catch (e) {
    return reply.code(404).send({ error: e instanceof Error ? e.message : '대기표를 확인하지 못했습니다.' });
} });
student.post('/api/student/waitlist', async (request, reply) => { try {
    const body = request.body || {}, studentId = store.studentId(String(body.grade), String(body.schoolClass), String(body.name));
    if (!studentId)
        throw new Error('학생을 찾을 수 없습니다.');
    const result = store.joinWaitlist(studentId, body.mood);
    emit('capacity');
    return result;
}
catch (e) {
    return reply.code(409).send({ error: e instanceof Error ? e.message : '대기를 신청하지 못했습니다.' });
} });
student.delete('/api/student/waitlist/:ticket', async (request, reply) => { try {
    store.cancelWait(String(request.params.ticket));
    emit('capacity');
    return { ok: true };
}
catch (e) {
    return reply.code(404).send({ error: e instanceof Error ? e.message : '대기를 취소하지 못했습니다.' });
} });
student.post('/api/student/attendance', async (request, reply) => { try {
    const body = request.body || {}, studentId = store.studentId(String(body.grade), String(body.schoolClass), String(body.name));
    if (!studentId)
        throw new Error('학생을 찾을 수 없습니다.');
    const result = store.addAttendance(studentId, body.direction, body.mood, body.waitlistTicket);
    emit('capacity');
    return result;
}
catch (e) {
    if (e instanceof CapacityError)
        return reply.code(409).send({ error: e.message, code: e.code, ...e.details });
    return reply.code(409).send({ error: e instanceof Error ? e.message : '저장하지 못했습니다.' });
} });
student.post('/api/student/counseling', async (request, reply) => { try {
    const body = request.body || {};
    if (!validDetails(body.details))
        throw new Error('상담 신청 내용을 확인해 주세요.');
    const studentId = store.studentId(String(body.grade), String(body.schoolClass), String(body.name));
    if (!studentId)
        throw new Error('학생을 찾을 수 없습니다.');
    const id = store.addRequest(studentId, body.details, requestPriority(body.details));
    emit('counseling');
    return { id, timestamp: new Date().toISOString() };
}
catch (e) {
    return reply.code(400).send({ error: e instanceof Error ? e.message : '상담 신청을 저장하지 못했습니다.' });
} });
if (existsSync(dist))
    await student.register(staticPlugin, { root: dist, wildcard: false });
student.setNotFoundHandler((request, reply) => request.url.startsWith('/admin') || request.url.startsWith('/api/admin') ? reply.code(404).send({ error: '이 주소에서는 관리자 화면을 사용할 수 없습니다.' }) : existsSync(resolve(dist, 'index.html')) ? reply.sendFile('index.html') : reply.code(404).send({ error: '학생 화면을 먼저 빌드해야 합니다.' }));
await Promise.all([
    admin.listen({ host: '127.0.0.1', port: adminPort }),
    student.listen({ host: studentHost, port: studentPort }),
]);
void startAccess().catch(error => {
    accessStatus = { state: 'error', message: error instanceof Error ? error.message : '학생용 사설망 접속을 시작하지 못했습니다.' };
    emit();
});
setInterval(() => { const active = store.activeSession(); if (!active && accessStatus.state === 'online') {
    accessGeneration++;
    accessStatus = { state: 'stopped' };
    currentStudentToken = '';
    emit();
} }, 30_000).unref();
setInterval(() => { store.reconcileQueue(); emit('capacity'); }, 15_000).unref();
setInterval(() => { try {
    store.backup();
}
catch { /* The admin dashboard reports explicit backup failures. */ } }, 24 * 60 * 60 * 1000).unref();
let shuttingDown = false;
async function shutdown() {
    if (shuttingDown)
        return;
    shuttingDown = true;
    accessGeneration++;
    accessStatus = { state: 'stopped' };
    store.stopSessions();
    await Promise.allSettled([admin.close(), student.close()]);
    process.exit(0);
}
process.once('SIGINT', () => void shutdown());
process.once('SIGTERM', () => void shutdown());
console.log(`Wee Check 관리자: http://127.0.0.1:${adminPort}/admin`);
console.log(`Wee Check AP 학생 서버: ${studentHost}:${studentPort}`);
